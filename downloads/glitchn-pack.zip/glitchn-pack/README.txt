GLITCH'N PACK  /  PAQUETE GLITCH'N
glitchn.net

logos/        Glitch'n logos (SVG, PNG)
stickers/     Stickers, 3 in and 6 in (PDF, SVG)
chip-labels/  Chip labels. Print at 100% on sticker paper.
chip-maps/    What each leg of each chip does (PDF, JPG)
colors/       Glitch'n colors

logos/        Logos de Glitch'n (SVG, PNG)
stickers/     Calcomanías, 3 y 6 pulgadas (PDF, SVG)
chip-labels/  Etiquetas para chips. Imprime al 100 % en papel adhesivo.
chip-maps/    Qué hace cada pata de cada chip (PDF, JPG)
colors/       Colores de Glitch'n

(c) Glitch'n. School of Games, Arts, Media and Engineering, Arizona State University.
